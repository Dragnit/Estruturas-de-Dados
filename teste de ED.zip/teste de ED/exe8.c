#include <stdio.h>

int pesquisaBinariaRec(int esq, int dir,int n, int vector[n], int num){

  int meio = (esq + dir)/ 2;

  if(esq != dir){
    if(num == vector[meio])
      return meio;
    else
    {
      if (num < vector[meio]){
        return pesquisaBinariaRec(esq,meio-1,n,vector,num);
      }
      else{
        return pesquisaBinariaRec(meio+1, dir,n,vector,num);
      }
    }
  }
  else
  {
    if(num==vector[esq])
      return  esq;
    else
      return -1;
  }

}

int pesquisaBinariaInt(int n, int vector[n], int num){

  int esq = 0, dir = n-1, meio, a;

    while(esq != dir){
      meio = (esq + dir)/2;
      if(num == vector[meio])
        return meio;
      else
        if(num < vector[meio])
          dir = meio -1;
        else
          esq = meio + 1;
    }
    if(esq == dir){
      if(num == vector[esq])
        a = esq;
      else{
        a = -1;
      }
    }
  return a;
}

int main(){

  int vector[7]={2,4,5,6,9,10,12};
  int num = 10;

  printf("o %d esta no indice %d\n", num, pesquisaBinariaRec(0,6,7,vector,num));
  num = 10;
  printf("o %d esta no indice %d\n", num, pesquisaBinariaInt(7,vector,num));



}
