//Guilherme Rodrigues 2020154390
//Rafael Castro 2020155096
//Estrutura de Dados
//Realizado de dia 15 a 30
#include <stdio.h>
#include <string.h> // Biblioteca para mexer com ficheiros
#include <stdlib.h> // Biblioteca para dar nome ao ficheiro



typedef struct jogadorDados //definiçao da estrutura dos dados do jogador
{
  char nome [20];
  int idade;
  float altura;
  int numeroCamisola;
} jogador;

typedef struct jogosDados //definiçao da estrutura dos dados dos jogos
{
  char adversario [20];
  char resultado;
  int temporada;
  char local [20];
} jogo;

int tabelaJogador(jogador Tjogador [10], int jgd) // aqui sao pedidos e lidos os dados dos jogadores introduzidos pelo utilizador
{
  char nome [50];
  char res [54];
  printf("insira o nome da tabela: ");
  scanf("%s", nome);
  sprintf(res, "%s.txt", nome);
  FILE *fp = fopen(res, "w");

  printf("Insira o primeiro nome do jogador: ");
  scanf("%s", &Tjogador[jgd].nome);
  printf("Insira a Idade: ");
  scanf("%d", &Tjogador[jgd].idade);
  if(Tjogador[jgd].idade < 0 || Tjogador[jgd].idade > 99)
    {
      printf("Idade Invalida");
      fclose(fp);
      return jgd;
    }
  printf("Insira a altura do jogador: ");
  scanf("%f", &Tjogador[jgd].altura);
  printf("Numero da Camisola: ");
  scanf("%d", &Tjogador[jgd].numeroCamisola);

  fprintf(fp, "%s\n", Tjogador[jgd].nome);
  fprintf(fp, "%d\n", Tjogador[jgd].idade);
  fprintf(fp, "%.2f\n", Tjogador[jgd].altura);
  fprintf(fp, "%d\n", Tjogador[jgd].numeroCamisola);
  fclose(fp);
  return jgd+1;
}

int tabelaJogos(jogo Tjogo [10], int jg) //aqui sao pedidos e lidos os dados dos jogos inseridos pelo utilizador
{

  char nome [50];
  char res [54];
  printf("insira o nome da tabela: ");
  scanf("%s", nome);
  sprintf(res, "%s.txt", nome);
  FILE *fp = fopen(res, "w");

  printf("Insira o nome do adversario: ");
  scanf("%s", &Tjogo[jg].adversario);
  printf("Insira o resultado (E/V/D): ");
  fflush(stdin);
  scanf("%c", &Tjogo[jg].resultado);
  printf("Insira a Temporada: ");
  scanf("%d", &Tjogo[jg].temporada);
  printf("Insira o Local do jogo: ");
  scanf("%s", &Tjogo[jg].local);

  fprintf(fp, "%s\n", Tjogo[jg].adversario);
  fprintf(fp, "%c\n", Tjogo[jg].resultado);
  fprintf(fp, "%d\n", Tjogo[jg].temporada);
  fprintf(fp, "%s\n", Tjogo[jg].local);
  fclose(fp);

  return jg+1;
}

void mostrarJogador(jogador Tjogador [10], int jgd) // funçao que fara a demonstraçao dos dados dos jogadores inseridos (tabela com os dados dos jogadores)
{
  printf("%d", jgd);
  int i = 0;

  while (i < jgd)
  {

    puts("-------------------------");
    fprintf("Nome                : %s\n", Tjogador [i].nome);
    printf("Idade               :\n", Tjogador [i].idade);
    printf("Altura              : %0.2f\n", Tjogador [i].altura);
    printf("Numero da Camisola  : %d\n", Tjogador [i].numeroCamisola);
    puts("------------------------");

    i++;
  }
}

void mostrarJogo(jogo Tjogo [10], int jg) // funçao que fara a demonstracao dos dados dos jogos inseridos (tabela com os dados dos jogos)
{
  printf("%d", jg);
  int i = 0;

  while(i < jg) //loop para ler todos os dados inseridos
  {
    puts("----------------------");
    printf("Nome          :%s\n",Tjogo [i].adversario);
    printf("Resultado     :%s\n",Tjogo [i].resultado);
    printf("temporada     :%d",Tjogo [i].temporada);
    printf("\nLocal       :%s\n",Tjogo [i].local);
    puts("----------------------");

    i++;
  }
}

int adicionarJogadores(jogador Tjogador [10], int jgd)
{
  char nome [50];
  char res [54];
  printf("insira o nome da tabela: ");
  scanf("%s", nome);
  sprintf(res, "%s.txt", nome);
  FILE *fp = fopen(res, "a");

  printf("Insira o primeiro nome do jogador: ");
  scanf("%s", &Tjogador[jgd].nome);
  printf("Insira a Idade: ");
  scanf("%d", &Tjogador[jgd].idade);
  if(Tjogador[jgd].idade < 0 || Tjogador[jgd].idade > 99)
    {
      printf("Idade Invalida");
      fclose(fp);
      return jgd;
    }
  printf("Insira a altura do jogador: ");
  scanf("%f", &Tjogador[jgd].altura);
  printf("Numero da Camisola: ");
  scanf("%d", &Tjogador[jgd].numeroCamisola);

  fprintf(fp, "%s\n", Tjogador[jgd].nome);
  fprintf(fp, "%d\n", Tjogador[jgd].idade);
  fprintf(fp, "%.2f\n", Tjogador[jgd].altura);
  fprintf(fp, "%d\n", Tjogador[jgd].numeroCamisola);

  fclose(fp);
  return jgd+1;
}

int adicionarJogos(jogo Tjogo [10], int jg)
{
  char nome [50];
  char res [54];
  printf("insira o nome da tabela: ");
  scanf("%s", nome);
  sprintf(res, "%s.txt", nome);
  FILE *fp = fopen(res, "a");

  printf("Insira o nome do adversario: ");
  scanf("%s", &Tjogo[jg].adversario);
  printf("Insira o resultado (E/V/D): ");
  fflush(stdin);
  scanf("%c", &Tjogo[jg].resultado);
  printf("Insira a Temporada: ");
  scanf("%d", &Tjogo[jg].temporada);
  printf("Insira o Local do jogo: ");
  scanf("%s", &Tjogo[jg].local);

  fprintf(fp, "%s\n", Tjogo[jg].adversario);
  fprintf(fp, "%c\n", Tjogo[jg].resultado);
  fprintf(fp, "%d\n", Tjogo[jg].temporada);
  fprintf(fp, "%s\n", Tjogo[jg].local);

  fclose(fp);
  return jg+1;
}

int main()
{
  int jgd = 0;
  int jg = 0;

  char a;
  jogo Tjogo [10];
  jogador Tjogador [10];

  system("cls"); // limpa o ecra

  while(a != '7')
  {

    puts("-------------------------------------------------------------------");
    puts("                            MENU                                   ");
    puts("                                                                   ");
    puts("     O que pretende realizar?                                      ");
    puts("                                                                   ");
    puts("1 -- criar tabela de jogadores                                     ");
    puts("2 -- criar tabela de jogos                                         ");
    puts("3 -- Consultar tabela de jogadores                                 ");
    puts("4 -- Consultar tabela de jogos                                     ");
    puts("5 -- Adicionar jogadores                                           ");
    puts("6 -- Adicionar jogos                                               ");
    puts("7 -- Sair                                                          ");
    puts("-------------------------------------------------------------------");

    fflush(stdin); //limpa possivel memoria do teclado
    printf("Insira a opcao: ");
    scanf("%c", &a);


    system("cls"); //limpa o ecra

    switch (a)
    {
      case '1': jgd = tabelaJogador(Tjogador, jgd); break;
      case '2': jg = tabelaJogos(Tjogo, jg); break;
      case '3': mostrarJogador(Tjogador, jgd); break;
      case '4': mostrarJogo(Tjogo, jg); break;
      case '5': adicionarJogadores(Tjogador, jgd); break;
      case '6': adicionarJogos(Tjogo, jg); break;
      case '7':break;
    }
  }
  return 0;
}
