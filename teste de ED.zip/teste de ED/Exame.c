#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


#define TAM_C   50

typedef struct dados_das_compras * plista;

typedef struct dados_das_compras
{
  char nome[20];
  int dia, mes, ano;
  float valor;
  int hora, data;
  plista prox;
} compras;

int ficheiroCompras(compras Tcompras[50], int i)
  {
    time_t ddh;
    time(&ddh);
    scanf("%s", nome);
    sprintf("%s.txt", ctime(&ddh));
    FILE *fp = fopen(ctime(&ddh), "w");

    time_t ddh;
    time(&ddh);
    printf("Insira o nome da cliente: ");
    scanf("%s\n", &Tcompras[i].nome);
    printf("insira o valor da compra: ");
    scanf("%.2f\n", &Tcompras[i].valor);

    fprintf(fp,"dia/data/hora: %s",ctime(&ddh));
    fprintf(fp, "%s", Tcompras[i].nome);
    fprintf(fp, "%.2f\n", Tcompras[i].valor);
    fclose(fp);
    return i+1;
  }

void criacaoTablea(compras Tcompras[50], int i)
  {
    char nome [50];
    char res [54];
    printf("insira o nome da tabela: ");
    scanf("%s", nome);
    sprintf(res, "%s.txt", nome);
    FILE *fp = fopen(res, "r");

  if(fp == NULL)
  {
    printf("ERRO: o ficheiro nao existe ou nao pode ser lido, tente novamente.\n");
    break;
  }
  else
  {
    fscanf(fp,"%s %.2f",Tcompras[i].nome, Tcompras[i].valor);
    strcpy(Tcompras[i].nome, Tcompras[i].valor);
  }
}

void lista()
{
  typedef struct no * ponteiro;
typedef struct no
{
            estrutura dados_das_compras;
            ponteiro ant;
            plista prox;
} plista;
}

int main()
{
  i = ficheiroCompras(Tcompras, i);
  i = criacaoTabela(Tcompras,i);

}
