#include <stdio.h>
#include <string.h>

int main(){

  char nome[20];
  char tabNomes[5][20];
  char tabNomes2[5][20];
  strcpy(tabNomes[0], "joaquim");
  strcpy(tabNomes[1], "rosario");
  strcpy(tabNomes[2], "gabriela");
  strcpy(tabNomes[3], "lucia");
  strcpy(tabNomes[4], "lobo");

  FILE * file= fopen("tabNomes.txt","a+r");
  if(file != NULL)
  {
    for(int i = 0; i < 5; i++)
      fprintf(file, "%s\n",tabNomes[i]);

    rewind(file);

    while(fscanf(file,"%s", nome) != EOF)
      printf("%s\n",nome);

    rewind(file);

    while(fgets(nome,20,file) != NULL)
        printf("%s",nome);
  }
  else
    printf("Erro ao abrir o ficheiro!");

    fclose(file);

    FILE * file2 = fopen("tabNomes.dat","wrb");

    if(file2 != NULL)
    {

      fwrite(&tabNomes,sizeof(tabNomes),1,file2);
    /*  rewind(file2);

      fread(&tabNomes2,sizeof(tabNomes),1,file2);
      rewind(file);

      printf("lido do ficheiro binario!");
      for(int i = 0; i < 5; i++)
        fprintf(file2, "%s\n",tabNomes2[i]);
*/
      }
      else
        printf("Erro ao abrir o ficheiro!");

        fclose(file2);

      FILE * file3 = fopen("tabNomes.dat","rb");

      if(file2 != NULL)
      {
        fread(&tabNomes2,sizeof(tabNomes),1,file3);

        printf("lido do ficheiro binario!\n");
        for(int i = 0; i < 5; i++)
          printf("%s\n",tabNomes2[i]);

        }
      else
        printf("Erro ao abrir o ficheiro!");

        fclose(file3);

}
