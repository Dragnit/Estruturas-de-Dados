#include <stdio.h>

void ordenaVector(int n , int vector[n], int num){

  int var=0;

  for( n = n - 1; 0 <= n; n--){
    if(num < vector[n]){
      var = vector[n];
      vector[n]=num;
      vector[n+1]=var;
    }
  }
}

void ordenaPorInsecao(int n , int vector[n]){
  int var=0, j=0;

  for(int i = 1; i < n; i++){
    if(vector[i]<vector[i-1]){
      j=i-1;
      var = vector[i];
      while(vector[j] > var && j >= 0){
        vector[j+1]=vector[j];
        j--;
      }
      vector[j+1]=var;
    }
  }
}

void bubbleSort(int n, int vector[n]){
  int var=0;


  for(int j= 0; j < n-1; j++){
    for(int i=0; i < n-2; i++)
      if(vector[i] < vector[i+1]){
        var=vector[i];
        vector[i]=vector[i+1];
        vector[i+1]=var;
      }
  }
}

void bubbleSort2(int n, int vector[n]){
  int var=0;
  int j=0;
  int cont=0;


  while(j < n-1 && cont != n-2){
    cont=n-2;
    for(int i=0; i < n-2; i++)
      if(vector[i] < vector[i+1]){
        var=vector[i];
        vector[i]=vector[i+1];
        vector[i+1]=var;
        cont--;
      }
    j++;
  }
}


int main(){

  int n = 6;
  int vector[]={8,7,6,5,1,4};

  //ordenaVector(n,vector,1);

  //ordenaPorInsecao(n,vector);

  bubbleSort2(n,vector);

  for(int i =0; i < n; i++){
    printf("%d ", vector[i]);
  }

}
