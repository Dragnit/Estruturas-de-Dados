#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct dadosSensores //definiçao da estrutura dos dados dos sensores
{
  int referencia;
  float temperatura;
  float humidade;
  float carbono;
  int dia;
  int mes;
  int ano;
  int hora;
  int minuto;
}

int tabelaDados (Dados Tabela[10], int Dds)
{
  char nome[50];
  char res[50];
  printf("insira o nome d0 ficheiro: ");
  scanf("%s", nome);
  sprintf(res, "%s.txt", nome);
  FILE *fp = fopen(res, "w");

  printf("Insira a referencia\n");
  printf("%d", Tabela[Dds].referencia);
  printf("Insira a temperatura\n");
  scanf("%f", Tabela[Dds].temperatura);
  if(Tabela[Dds].temperatura < -10 ||Tabela[Dds].temperatura > 70)
  {
    printf("Temperatura invalida");
    break;
  }
  printf("Insira a humidade realtiva\n");
  scanf("%f", Tabela[Dds].humidade);
  if(Tabela[Dds].humidade < 0 ||Tabela[Dds].humidade > 1)
  {
    printf("Humidade invalida");
    break;
  }
  printf("Insira o nivel de CO2\n");
  scanf("%f", Tabela[Dds].carbono);
  if(Tabela[Dds].carbono < 0 ||Tabela[Dds].carbono > 10000)
  {
    printf("CO2 invalido");
    break;
  }
  printf("Insira a data (dia mes ano)\n");
  scanf("%d %d %d", Tabela[Dds].dia, Tabela[Dds].mes, Tabela[Dds].ano);
  printf("Insira a hora (hora minuto)");
  scanf("%d %d", Tabela[Dds].hora, Tabela[Dds].minuto);

  fprintf(fp, "%d\n", Tabela[Dds].referencia);
  fprintf(fp, "%f\n", Tabela[Dds].temperatura);
  fprintf(fp, "%f\n", Tabela[Dds].humidade);
  fprintf(fp, "%f\n", Tabela[Dds].carbono);
  fprintf(fp, "%d ", Tabela[Dds].dia);
  fprintf(fp, "%d ", Tabela[Dds].mes);
  fprintf(fp, "%d\n", Tabela[Dds].ano);
  fprintf(fp, "%d ", Tabela[Dds].hora);
  fprintf(fp, "%d\n", Tabela[Dds].minuto);
  fclose(fp);
  return Dds+1;
}

void consultaTabela(Dados Tabela[10], int Dds)
{
  printf("%d", Dds);
  int i = 0;

  while (i < Dds)
  {

    puts("-------------------------");
    printf("referencia                : %d\n", Tabela[i].referencia);
    printf("temperatura               :\n", Tabela[i].temperatura);
    printf("humidade                  : %0.2f\n", Tabela[i].humidade);
    printf("Dioxido de Carbono        : %d\n", Tabela[i].carbono);
    printf("data|hora                 : %d-%d-%d || %d:%d", Tabela[i].dia; Tabela[i].mes, Tabela[i].ano; Tabela[i].hora, Tabela[i].minuto);
    puts("------------------------");

    i++;
  }
}

int adicionaDados (Dados Tabela[10], int Dds)
{
  char nome[50];
  char res[50];
  printf("insira o nome d0 ficheiro: ");
  scanf("%s", nome);
  sprintf(res, "%s.txt", nome);
  FILE *fp = fopen(res, "a");

  printf("Insira a referencia\n");
  printf("%d", Tabela[Dds].referencia);
  printf("Insira a temperatura\n");
  scanf("%f", Tabela[Dds].temperatura);
  if(Tabela[Dds].temperatura < -10 ||Tabela[Dds].temperatura > 70)
  {
    printf("Temperatura invalida");
    break;
  }
  printf("Insira a humidade realtiva\n");
  scanf("%f", Tabela[Dds].humidade);
  if(Tabela[Dds].humidade < 0 ||Tabela[Dds].humidade > 1)
  {
    printf("Humidade invalida");
    break;
  }
  printf("Insira o nivel de CO2\n");
  scanf("%f", Tabela[Dds].carbono);
  if(Tabela[Dds].carbono < 0 ||Tabela[Dds].carbono > 10000)
  {
    printf("CO2 invalido");
    break;
  }
  printf("Insira a data (dia mes ano)\n");
  scanf("%d %d %d", Tabela[Dds].dia, Tabela[Dds].mes, Tabela[Dds].ano);
  printf("Insira a hora (hora minuto)");
  scanf("%d %d", Tabela[Dds].hora, Tabela[Dds].minuto);

  fprintf(fp, "%d\n", Tabela[Dds].referencia);
  fprintf(fp, "%f\n", Tabela[Dds].temperatura);
  fprintf(fp, "%f\n", Tabela[Dds].humidade);
  fprintf(fp, "%f\n", Tabela[Dds].carbono);
  fprintf(fp, "%d ", Tabela[Dds].dia);
  fprintf(fp, "%d ", Tabela[Dds].mes);
  fprintf(fp, "%d\n", Tabela[Dds].ano);
  fprintf(fp, "%d ", Tabela[Dds].hora);
  fprintf(fp, "%d\n", Tabela[Dds].minuto);
  fclose(fp);
  return Dds+1;
}

int main()
{
  int Dds = 0;

  char a;
  jogador Tabela [10];

  system("cls"); // limpa o ecra

  while(a != '4')
  {

    puts("-------------------------------------------------------------------");
    puts("                            MENU                                   ");
    puts("                                                                   ");
    puts("     O que pretende realizar?                                      ");
    puts("                                                                   ");
    puts("1 -- criar tabela de Dados                                         ");
    puts("2 -- Consultar tabela                                              ");
    puts("3 -- Adicionar Dados                                               ");
    puts("4 -- Sair                                                          ");
    puts("-------------------------------------------------------------------");

    fflush(stdin); //limpa possivel memoria do teclado
    printf("Insira a opcao: ");
    scanf("%c", &a);


    system("cls"); //limpa o ecra

    switch (a)
    {
      case '1': Dds = tabelaDados(Dados Tabela, Dds); break;
      case '3': consultaTabela(Dados Tabela, Dds); break;
      case '5': adicionarJogadores(Tjogador, jgd); break;
      case '6': adicionarJogos(Tjogo, jg); break;
      case '7':break;
    }
  }
  return 0;
}
