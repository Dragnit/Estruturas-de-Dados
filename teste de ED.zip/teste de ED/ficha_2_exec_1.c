#include <stdio.h>



int main(){

FILE * file;

char fileName[20];
char descriction[100];


    printf("Escreva o nome do ficheiro: ");
    gets(fileName);

    printf("De uma descricao ao ficheiro: ");
    gets(descriction);

    file = fopen("fileName.txt","w");

    fputs(descriction, file);

    fclose(file);

    file = fopen("fileName.txt","a");



}
