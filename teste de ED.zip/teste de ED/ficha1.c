#include <stdio.h>
#include <stdlib.h>

#define DIM 10

void criaVector(int vec[], int n){

    for (int i = 0; i < n; i++)
        vec[i] =  i + 1;
}

void escreveVector(int v[], int n ){
    printf("Vector\n");
    for(int i = 0 ; i < n; i++)
        printf("elemento %d :\t%d\n",i, v[i]);
}
void escreverElementosAleatorios(int vector[], int n){
    srand(5); // funçao para ter 5 numeros random
    for(int i = 0; i < n; i++){
        vector[i]= rand() % 50 + 1; //aqui define-se os numeros de 0 a 50
    }

}
void deslocarElementos(int vector[],int n){

    int aux=vector[0];

      for(int i=0; i < n; i++){
        vector[i]=vector[i+1];
      }
      vector[n-1]=aux;
}

void mediaDeParesEemparis(int vector[], int n){

    int numPares,numImpares,pares = 0,impares = 0;

      for(int i = 0; i < n; i++){
        if(vector[i]%2==0){
          numPares+=vector[i];
          pares++;
        }
        else{
          numImpares+=vector[i];
          impares++;
        }
      }
        printf("\nMedia dos numeros pares: %0.2f",(1.0*numPares/pares));
        printf("\nMedia dos numeros impares: %0.2f\n",(1.0*numImpares/impares));
}

void matriz_1(int m1[5][7]){

            for(int i = 0; i < 5 ;i++)
                  for(int j = 0; j < 7 ; j++)
                        m1[i][j]=j;
}
void matriz_2(int m2[5][7]){

      for(int i = 0 ; i < 5 ;i++){
          for(int j = 0 ; j < 7 ;j++){
                  m2[i][j]=i;
          }
      }
}

void escreveMatriz(int vector[5][7]){
    printf("Vector\n");
    for(int i = 0; i < 5; i++){
      for(int j = 0; j < 7; j++){
          printf(" %d ",vector[i][j]);
      }
      printf("\n");
    }
}

int main(){

 //int n= 10;
 //int vector[n];
 int mat1[5][7], mat2[5][7];

  matriz_1(mat1);
  escreveMatriz(mat1);
  matriz_2(mat2);
  escreveMatriz(mat2);

  //criaVector(vector,n);
  //escreverElementosAleatorios(vector,n);
  //deslocarElementos(vector,n);
  //escreveVector(vector,n);
  //mediaDeParesEemparis(vector,n);

}
