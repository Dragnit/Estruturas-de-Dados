#include <stdio.h>
#include <string.h>


struct coordenadas_ponto{
  float x;
  float y;
};

typedef struct coordenadas_ponto ponto;

struct rectangulo{
  float xmin;
  float xmax;
  float ymin;
  float ymax;
};

typedef struct rectangulo rect;

float arearectangulo(rect p){

  float area;
  float x = p.xmax;
  float y = p.xmax;

    if(p.xmax < p.xmin){
       x = p.xmin;
       p.xmin = p.xmax;
     }
     if(p.ymax < p.ymin){
        y = p.xmin;
        p.ymin = p.ymax;
      }

    area = (x - p.xmin) * (y - p.ymin);

  return area;
}

// subprograma escreve_ponto
// escreve um ponto com as coordenadas x e y na forma (x,y)
void escreve_ponto(ponto p){
  printf("As coordenadas dos pontos sao (%.0f,%.0f)\n", p.x, p.y);
}
// subprograma funcao
void funcao(ponto a, ponto b) {
  char h[15], v[15];
if(a.x < b.x) strcpy(h,"esquerda");
else strcpy(h,"direita");
if(a.y < b.y) strcpy(v,"baixo");
else strcpy(v,"cima");
printf("O primeiro ponto está à %s e em %s do segundo ponto!\n",h,v);
}
int main() {
// declarar pontos p1 e p2;
  ponto p1, p2;
  rect p;
  float area;
// pedir ao utilizador e ler as coordenadas dos pontos p1 e p2
/*printf("Digite os pontos\n");
  scanf("%f,%f",&p1.x,&p1.y );
  scanf("%f,%f",&p2.x,&p2.y );
// chamar o subprograma escreve_ponto para mostrar os pontos lidos
  escreve_ponto(p1);
  escreve_ponto(p2);
// chamar o subprograma funcao aplicado aos pontos p1 e p2
  funcao(p1,p2);*/
  printf("Digite os pontos do rectangulo\n");
  printf("Xmax:"); scanf("%f", &p.xmax);
  printf("Xmin:"); scanf("%f", &p.xmin);
  printf("Ymax:"); scanf("%f", &p.ymax);
  printf("Ymin:"); scanf("%f", &p.ymin);

  area = arearectangulo(p);
  printf("A area do rectagulo e %.2f\n", area);

return 0; }
