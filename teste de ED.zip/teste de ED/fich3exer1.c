#include <stdio.h>

//...
struct estrutura_data {
  int dia;
  int mes;
  int ano; // tambem poderia ser uma string int ano;
};

typedef struct estrutura_data data;

/* le uma data da consola (standard input) na forma dia-mes-ano devolve a estrutura que descreve a data */
data le_data()
{
  data dat;

  printf("Escreva a data no formato dia-mes-ano\n");
  scanf("%d-%d-%d",&dat.dia, &dat.mes, &dat.ano);
  if(dat.dia > 31 && dat.dia < 0){
    printf("Dia Invalido\n");
  }
  if(dat.mes > 12 && dat.mes < 0){
    printf("Mes Invalido\n");
  }

 return dat;
}

// escreve uma data na consola (standard output) na forma dia-mes-ano
void escreve_data(data d) {
  printf("")
}
/* compara duas datas
se a 1a data e posterior a 2a data devolve '>' se a 1a data e anterior a 2a data devolve '<' se as duas datas sao iguais devolve '=' */
//char compara_datas(data d1, data d2) {/*...*/}
// determina a "maior" data entre duas datas d1 e d2 */
//data maior_data(data d1, data d2) {/*...*/}
// testa as funcoes anteriores
int main() {

      data dat1, dat2;

      dat1 = le_data();
      dat2 = le_data();

escreve_data(dat1); escreve_data(dat2);
// usar compara_datas para obter a data mais recente entre dat1 e dat2 /*...*/
// usar maior_data para encontrar a “maior” data entre dat1 e dat2 /*...*/
return 0; }
