#include <stdio.h>
#include <string.h>

struct funcionario{
  int num;
  char nome[50];
  char tarefa[50];
  float salario;
};

typedef struct funcionario funcio;

void add_funcionario(funcio func[]){

  for(int i=0;i < 2;i++) {
    printf("numero: ");
    scanf("%d", &func[i].num);
    fflush(stdin);
    printf("nome: ");
    gets(func[i].nome);
    printf("tarefa: ");
    gets(func[i].tarefa);
    printf("salario: ");
    scanf("%f",&func[i].salario);
  }
}

void list_funcionarios(funcio func[]){

  for(int i=0;i < 2 ;i++) {
    printf("numero: %d\n",func[i].num);
    printf("nome: %s\n",func[i].nome);
    printf("tarefa: %s\n",func[i].tarefa);
    printf("salario: %0.0f\n",func[i].salario);
  }
}

void list_funcionarios_por_salario(funcio func[],int salario,int n){

  for(int i=0;i < n ;i++) {
    if(func[i].salario > salario){
      printf("numero: %d\n",func[i].num);
      printf("nome: %s\n",func[i].nome);
      printf("tarefa: %s\n",func[i].tarefa);
      printf("salario: %0.0f\n",func[i].salario);
    }
  }
}

funcio list_funcionarios_nome(funcio func[], int n, char nome[]){

funcio f;

  for(int i=0;i < n ;i++) {
    if(strcmp(func[i].nome, nome) == 0){
      printf("numero: %d\n",func[i].num);
      printf("nome: %s\n",func[i].nome);
      printf("tarefa: %s\n",func[i].tarefa);
      printf("salario: %0.0f\n",func[i].salario);
    }
  }

  return f;
}

void actualizar_funcionarios(funcio func[], int n,int num){

  for(int i=0;i < n ;i++) {
    if(func[i].num == num){
      printf("numero: ");
      scanf("%d", &func[i].num);
      fflush(stdin);
      printf("nome: ");
      gets(func[i].nome);
      printf("tarefa: ");
      gets(func[i].tarefa);
      printf("salario: ");
      scanf("%f",&func[i].salario);
    }
  }
}

int main(){
  char nome[20];
  funcio func[10];

     add_funcionario(func);
     list_funcionarios(func);
     list_funcionarios_por_salario(func,500,2);
}
