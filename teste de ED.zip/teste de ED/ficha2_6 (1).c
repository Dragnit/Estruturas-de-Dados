#include<stdio.h>
#include<string.h>

int main()
{
  char tabNomes[5][15];
  char tn[5][15];

  //tabNomes[0]="ana";//errado!
  strcpy(tabNomes[0],"ana asdas");
  //printf("\nnome 0: %s\n",tabNomes[0]);
  strcpy(tabNomes[1],"bruno wrewr");
  strcpy(tabNomes[2],"carla");
  strcpy(tabNomes[3],"daniel");
  strcpy(tabNomes[4],"elsa");

char nome[15];

//ficheiro de texto
FILE * ft = fopen("nomes.txt","a+r");

if(ft != NULL)
{
  for(int i=0; i<5; i++)
    fprintf(ft,"%s\n",tabNomes[i]);

  rewind(ft);

  while(fscanf(ft,"%s",nome)!=EOF)
    printf("%s\n",nome);
  //ou
  rewind(ft);
  while(fgets(nome,15,ft)!=NULL)
    printf("%s",nome);
}
else printf("\nerro na abertura do ficheiro de texto!\n");

fclose(ft);

//ficheiro binario
// tabela de 5 strings
FILE *fb = fopen("tabelaNomes.dat","wrb");

if(fb != NULL)
{
  fwrite(&tabNomes,sizeof(tabNomes),1,fb);
  //sizeof(char[5][15])
  //sizeof(5*char[15])
/*
  rewind(fb);
  fread(&tn,sizeof(tabNomes),1,fb);

  printf("\nlido do ficheiro binario\n");
  for(int j=0; j<5;j++)
    printf("%s\n",tn[j]);
*/
}
else printf("\nerro na abertura do ficheiro binario!\n");

fclose(fb);

FILE * fbl = fopen("tabelaNomes.dat","rb");
if(fbl!= NULL)
{
  fread(&tn,sizeof(tabNomes),1,fbl);

  printf("\nlido do ficheiro binario\n");
  for(int j=0; j<5;j++)
    printf("%s\n",tn[j]);
}
else printf("\nerro na abertura, para ler, do ficheiro binário");

fclose(fbl);

// 5 strings


return 1;
}
