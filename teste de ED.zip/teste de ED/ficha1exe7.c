#include <stdio.h>


void lerVector(int m, int n, int matriz[][n]){

   for(int i= 0 ; i < m; i++)
      for(int j = 0; j < n; j++){
          printf("Elemento[%d][%d]",i,j);
          scanf("%d", &matriz[i][j]);
        }

}

void numOcorrencias(int m, int n, int matriz[][n], int num){

  int a=0;

    for(int i = 0; i < m; i++)
      for(int j =0; j < n; j++)
        if(num==matriz[i][j])
            a++;

    printf("O numero: %d - ocorreu %d vezes.", num, a );

}

int ultimaOcorrencia( int n ,int matriz[n], int num){

  int a = -1;

    for(int i=0; i < n; i++){
      if(matriz[i]== num)
         a = i;
    }

  return a;
}

int primeiraOcorrencia( int n ,int matriz[n], int num){

  int a = -1, i = 0;

    while(i < n){
      if(matriz[i]== num){
         a = i;
         break;
       }
        i++
      }

  return a;
}

int main(){

  int linhas = 0, colunas = 0, num = 0;

  printf("Digite o numero de linhas: ");
  scanf("%d", &linhas);
  //printf("\nDigite o numero de colunas: ");
//  scanf("%d", &colunas);

  int vector[linhas];

  //lerVector(linhas,colunas,vector);

  printf("Digite o numero para ver a sua ocorrecia: ");
  scanf("%d", &num);

  numOcorrencias(linhas,colunas,vector,num);

}
