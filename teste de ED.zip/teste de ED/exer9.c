#include <stdio.h>

int encontraMax(int n,int vector[n], int numElementos){

  int max = 0;
  int linha = 0;

  for(int i = 0; i < numElementos; i++){
      if(vector[i] >= max){
         max = vector[i];
         linha = i;
       }
  }
return linha;
}
void trocaElementos(int n, int vector[n], int elem1, int elem2){

  int var=0;

    var = vector[elem1];
    vector[elem1] = vector[elem2];
    vector[elem2] = var;

}

void ordenaVector(int n, int vector[n]){

int var = 0;

    for(int i = 0; i < n; i++){
      for(int j = 0; j < n; j++){
        if(vector[j] > vector[n-1]){
           var = vector[j];
           vector[j] = vector[n-1];
           vector[n-1] = var;
         }
      }
      n--;
    }
}

int main(){
  int vector[8]={6,8,7,3,1,5,2,4};

  //printf("o elemento maximo esta no indice %d \n", encontraMax(8,vector,8));

  //trocaElementos(8,vector,5,7);

  for(int i =0; i < 8; i++){
    printf("%d ", vector[i]);
  }

  ordenaVector(8,vector);
  printf("\n");
  for(int i =0; i < 8; i++){
    printf("%d ", vector[i]);
  }

}
