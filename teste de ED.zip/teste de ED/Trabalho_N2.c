// João Pedro Martins Alves (a2020141847)
// Guilherme António De Souza Rodrigues (a2020154390)
// Estruturas de Dados
// Inicidado a 19/06/2021
// Ultima vez modificado em 01/06/2021

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// definir as macros para o tamanho das tabelas
#define TAM_S   30
#define TAM_T   20
#define TAM_T_A 8

int contador = 1, contador_jogo = 1;

typedef struct dados_do_jogo * plista;

typedef struct dados_do_jogador
{
  char nome[TAM_S];
  int dia_n, mes_n, ano_n;
  float altura;
  int peso;
  int numero_da_camisola;
} jogador;

typedef struct dados_da_equipa
{
  char nome_da_equipa[TAM_S];
  jogador jogadores[TAM_T];
  plista prox;
} equipa;

typedef struct dados_do_jogo
{
  char nome_equipa_1[TAM_S], nome_equipa_2[TAM_S];
  jogador jogadores_1[TAM_T], jogadores_2[TAM_T];
  int dia_j, mes_j, ano_j, horas, minutos;
  int resultado_A, resultado_B;
  plista prox;
} jogo;

void nome_das_equipas(equipa equipas [TAM_T_A])
{
  fflush(stdin);
  printf("Insira o nome da equipa 1: ");
  scanf("%s", equipas[0].nome_da_equipa);

  fflush(stdin);
  printf("Insira o nome da equipa 2: ");
  scanf("%s", equipas[1].nome_da_equipa);

  fflush(stdin);
  printf("Insira o nome da equipa 3: ");
  scanf("%s", equipas[2].nome_da_equipa);

  fflush(stdin);
  printf("Insira o nome da equipa 4: ");
  scanf("%s", equipas[3].nome_da_equipa);

  fflush(stdin);
  printf("Insira o nome da equipa 5: ");
  scanf("%s", equipas[4].nome_da_equipa);

  fflush(stdin);
  printf("Insira o nome da equipa 6: ");
  scanf("%s", equipas[5].nome_da_equipa);

  fflush(stdin);
  printf("Insira o nome da equipa 7: ");
  scanf("%s", equipas[6].nome_da_equipa);

  fflush(stdin);
  printf("Insira o nome da equipa 8: ");
  scanf("%s", equipas[7].nome_da_equipa);
  fflush(stdin);
}

void ler_dados(equipa equipas[TAM_T])
{
  int i = 0;

  FILE * f_1 = fopen("jogadores_1.txt","r");

  if(f_1 == NULL)
  {
    printf("ERRO: o ficheiro 1 nao existe ou nao pode ser lido, tente novamente.\n");
    exit(1);
  }
  else
  {
    printf("Ficheiro 1 aberto com sucesso.\n");

    for (i; i < 20; i++)
      fscanf(f_1,"%s %d/%d/%d %.2f %d %d", &equipas[0].jogadores[i].nome, &equipas[0].jogadores[i].dia_n, &equipas[0].jogadores[i].mes_n, &equipas[0].jogadores[i].ano_n, &equipas[0].jogadores[i].altura, &equipas[0].jogadores[i].peso, &equipas[0].jogadores[i].numero_da_camisola);
  }
  fclose(f_1);

  FILE * f_2 = fopen("jogadores_2.txt","r");

  if(f_2 == NULL)
  {
    printf("ERRO: o ficheiro 2 nao existe ou nao pode ser lido, tente novamente.\n");
    exit(2);
  }
  else
  {
    printf("Ficheiro 2 aberto com sucesso.\n");

    for (i; i < 20; i++)
      fscanf(f_2,"%s %d/%d/%d %.2f %d %d", &equipas[1].jogadores[i].nome, &equipas[1].jogadores[i].dia_n, &equipas[1].jogadores[i].mes_n, &equipas[1].jogadores[i].ano_n, &equipas[1].jogadores[i].altura, &equipas[1].jogadores[i].peso, &equipas[1].jogadores[i].numero_da_camisola);
  }
  fclose(f_2);

  FILE * f_3 = fopen("jogadores_3.txt","r");

  if(f_3 == NULL)
  {
    printf("ERRO: o ficheiro 3 nao existe ou nao pode ser lido, tente novamente.\n");
    exit(3);
  }
  else
  {
    printf("Ficheiro 3 aberto com sucesso.\n");

    for (i; i < 20; i++)
      fscanf(f_3,"%s %d/%d/%d %.2f %d %d", &equipas[2].jogadores[i].nome, &equipas[2].jogadores[i].dia_n, &equipas[2].jogadores[i].mes_n, &equipas[2].jogadores[i].ano_n, &equipas[2].jogadores[i].altura, &equipas[2].jogadores[i].peso, &equipas[2].jogadores[i].numero_da_camisola);
  }
  fclose(f_3);

  FILE * f_4 = fopen("jogadores_4.txt","r");

  if(f_4 == NULL)
  {
    printf("ERRO: o ficheiro 4 nao existe ou nao pode ser lido, tente novamente.\n");
    exit(4);
  }
  else
  {
    printf("Ficheiro 4 aberto com sucesso.\n");

    for (i; i < 20; i++)
      fscanf(f_4,"%s %d/%d/%d %.2f %d %d", &equipas[3].jogadores[i].nome, &equipas[3].jogadores[i].dia_n, &equipas[3].jogadores[i].mes_n, &equipas[3].jogadores[i].ano_n, &equipas[3].jogadores[i].altura, &equipas[3].jogadores[i].peso, &equipas[3].jogadores[i].numero_da_camisola);
  }
  fclose(f_4);

  FILE * f_5 = fopen("jogadores_5.txt","r");

  if(f_5 == NULL)
  {
    printf("ERRO: o ficheiro 5 nao existe ou nao pode ser lido, tente novamente.\n");
    exit(5);
  }
  else
  {
    printf("Ficheiro 5 aberto com sucesso.\n");

    for (i; i < 20; i++)
      fscanf(f_5,"%s %d/%d/%d %.2f %d %d", &equipas[4].jogadores[i].nome, &equipas[4].jogadores[i].dia_n, &equipas[4].jogadores[i].mes_n, &equipas[4].jogadores[i].ano_n, &equipas[4].jogadores[i].altura, &equipas[4].jogadores[i].peso, &equipas[4].jogadores[i].numero_da_camisola);
  }
  fclose(f_5);

  FILE * f_6 = fopen("jogadores_6.txt","r");

  if(f_6 == NULL)
  {
    printf("ERRO: o ficheiro 6 nao existe ou nao pode ser lido, tente novamente.\n");
    exit(6);
  }
  else
  {
    printf("Ficheiro 6 aberto com sucesso.\n");

    for (i; i < 20; i++)
      fscanf(f_6,"%s %d/%d/%d %.2f %d %d", &equipas[5].jogadores[i].nome, &equipas[5].jogadores[i].dia_n, &equipas[5].jogadores[i].mes_n, &equipas[5].jogadores[i].ano_n, &equipas[5].jogadores[i].altura, &equipas[5].jogadores[i].peso, &equipas[5].jogadores[i].numero_da_camisola);
  }
  fclose(f_6);

  FILE * f_7 = fopen("jogadores_7.txt","r");

  if(f_7 == NULL)
  {
    printf("ERRO: o ficheiro 7 nao existe ou nao pode ser lido, tente novamente.\n");
    exit(7);
  }
  else
  {
    printf("Ficheiro 7 aberto com sucesso.\n");

    for (i; i < 20; i++)
      fscanf(f_7,"%s %d/%d/%d %.2f %d %d", &equipas[6].jogadores[i].nome, &equipas[6].jogadores[i].dia_n, &equipas[6].jogadores[i].mes_n, &equipas[6].jogadores[i].ano_n, &equipas[6].jogadores[i].altura, &equipas[6].jogadores[i].peso, &equipas[6].jogadores[i].numero_da_camisola);
  }
  fclose(f_7);

  FILE * f_8 = fopen("jogadores_8.txt","r");

  if(f_8 == NULL)
  {
    printf("ERRO: o ficheiro 8 nao existe ou nao pode ser lido, tente novamente.\n");
    exit(8);
  }
  else
  {
    printf("Ficheiro 8 aberto com sucesso.\n");

    for (i; i < 20; i++)
      fscanf(f_8,"%s %d/%d/%d %.2f %d %d", &equipas[7].jogadores[i].nome, &equipas[7].jogadores[i].dia_n, &equipas[7].jogadores[i].mes_n, &equipas[7].jogadores[i].ano_n, &equipas[7].jogadores[i].altura, &equipas[7].jogadores[i].peso, &equipas[7].jogadores[i].numero_da_camisola);
  }
  fclose(f_8);
}

void escrever_aleatorio(equipa equipas [TAM_T_A])
{
  int num_t = 8, i = 0, x;
  equipa b[TAM_T_A];

  while (num_t >= 0)
  {
    if (num_t > 0)
    {
      x = rand() % num_t;
      strcpy(b[i].nome_da_equipa, equipas[x].nome_da_equipa);
      b[i].jogadores[x] = equipas[x].jogadores[x];

      for (x; x < num_t - 1; x++)
      {
        strcpy(equipas[x].nome_da_equipa, equipas[x+1].nome_da_equipa);
        equipas[x].jogadores[x] = equipas[x+1].jogadores[x+1];;
      }
      i = i + 1;
      num_t = num_t - 1;
    }
    else
    {
      strcpy(b[i].nome_da_equipa, equipas[num_t].nome_da_equipa);
      b[i].jogadores[x] = equipas[num_t].jogadores[num_t];
      num_t = num_t - 1;
    }
  }
  printf("Equipas colocadas aleatoriamente com sucesso.\n");
}

void torneio(equipa equipas[TAM_T_A])
{
  equipa b[TAM_T_A];

  plista lista = NULL;// declara a lista vazia

  //Primeiro jogo (Quartos de final)
  plista no_1 = (plista)malloc(sizeof(jogo));

  //Segundo jogo (Quartos de final)
  plista no_2 = (plista)malloc(sizeof(jogo));

  //Terceiro jogo (Quartos de final)
  plista no_3 = (plista)malloc(sizeof(jogo));

  //Quarto jogo (Quartos de final)
  plista no_4 = (plista)malloc(sizeof(jogo));

  //Quinto jogo (Meias finais)
  plista no_5 = (plista)malloc(sizeof(jogo));

  //Sexto jogo (Meias finais)
  plista no_6 = (plista)malloc(sizeof(jogo));

  //Setimo jogo (Final)
  plista no_7 = (plista)malloc(sizeof(jogo));

  //Equipa Vencedora do torneio
  plista no_8 = (plista)malloc(sizeof(jogo));

  if (contador == 3)
  {
    //Primeiro jogo (Quartos de final)
    strcpy(no_1 -> nome_equipa_1, b[0].nome_da_equipa);
    strcpy(no_1 -> nome_equipa_2, b[1].nome_da_equipa);
    strcpy(no_1 -> jogadores_1[0].nome, b[0].jogadores[0].nome);
    strcpy(no_1 -> jogadores_2[0].nome, b[1].jogadores[0].nome);

    for (int i = 0; i < 20; i++)
    {
      no_1 -> jogadores_1[i].dia_n = b[0].jogadores[i].dia_n;
      no_1 -> jogadores_1[i].mes_n = b[0].jogadores[i].mes_n;
      no_1 -> jogadores_1[i].ano_n = b[0].jogadores[i].ano_n;
      no_1 -> jogadores_1[i].altura = b[0].jogadores[i].altura;
      no_1 -> jogadores_1[i].peso = b[0].jogadores[i].peso;
      no_1 -> jogadores_1[i].numero_da_camisola = b[0].jogadores[i].numero_da_camisola;
    }

    for (int i = 0; i < 20; i++)
    {
      no_1 -> jogadores_2[i].dia_n = b[1].jogadores[i].dia_n;
      no_1 -> jogadores_2[i].mes_n = b[1].jogadores[i].mes_n;
      no_1 -> jogadores_2[i].ano_n = b[1].jogadores[i].ano_n;
      no_1 -> jogadores_2[i].altura = b[1].jogadores[i].altura;
      no_1 -> jogadores_2[i].peso = b[1].jogadores[i].peso;
      no_1 -> jogadores_2[i].numero_da_camisola = b[1].jogadores[i].numero_da_camisola;
    }

    do
    {
      fflush(stdin);
      printf("Resultado do primeiro jogo (RR-RR): ");
      scanf("%d-%d", &no_1 -> resultado_A, &no_1 -> resultado_B);

      fflush(stdin);
      if (no_1 -> resultado_A == no_1 -> resultado_B)
        printf("O resultado resulta em um epate, tente outra vez\n");
      else
      {
        fflush(stdin);
        printf("\nData do primeiro jogo (DD/MM/AAAA): ");
        scanf("%d/%d/%d", &no_1 -> dia_j, &no_1 -> mes_j, &no_1 -> ano_j);

        fflush(stdin);
        printf("\nHora do primeiro jogo (HH:MM): ");
        scanf("%d:%d", &no_1 -> horas, &no_1 -> minutos);
        fflush(stdin);
      }
    }
    while (no_1 -> resultado_A == no_1 -> resultado_B);

    no_1 -> prox = no_5;

    if (no_1 -> resultado_A > no_1 -> resultado_B)
    {
      strcpy(no_5 -> nome_equipa_1, no_1 -> nome_equipa_1);
      for (int i = 0; i < 20; i++)
      {
        no_5 -> jogadores_1[i].dia_n = no_1 -> jogadores_1[i].dia_n;
        no_5 -> jogadores_1[i].mes_n = no_1 -> jogadores_1[i].mes_n;
        no_5 -> jogadores_1[i].ano_n = no_1 -> jogadores_1[i].ano_n;
        no_5 -> jogadores_1[i].altura = no_1 -> jogadores_1[i].altura;
        no_5 -> jogadores_1[i].peso = no_1 -> jogadores_1[i].peso;
        no_5 -> jogadores_1[i].numero_da_camisola = no_1 -> jogadores_1[i].numero_da_camisola;
      }
    }
    else
    {
      strcpy(no_5 -> nome_equipa_1, no_1 -> nome_equipa_2);
      for (int i = 0; i < 20; i++)
      {
        no_5 -> jogadores_1[i].dia_n = no_1 -> jogadores_2[i].dia_n;
        no_5 -> jogadores_1[i].mes_n = no_1 -> jogadores_2[i].mes_n;
        no_5 -> jogadores_1[i].ano_n = no_1 -> jogadores_2[i].ano_n;
        no_5 -> jogadores_1[i].altura = no_1 -> jogadores_2[i].altura;
        no_5 -> jogadores_1[i].peso = no_1 -> jogadores_2[i].peso;
        no_5 -> jogadores_1[i].numero_da_camisola = no_1 -> jogadores_2[i].numero_da_camisola;
      }
    }
  }
  else
  {
    if (contador == 4)
    {
      //Segundo jogo (Quartos de final)
      strcpy(no_2 -> nome_equipa_1, b[2].nome_da_equipa);
      strcpy(no_2 -> nome_equipa_2, b[3].nome_da_equipa);
      strcpy(no_2 -> jogadores_1[0].nome, b[2].jogadores[0].nome);
      strcpy(no_2 -> jogadores_2[0].nome, b[3].jogadores[0].nome);

      for (int i = 0; i < 20; i++)
      {
        no_2 -> jogadores_1[i].dia_n = b[2].jogadores[i].dia_n;
        no_2 -> jogadores_1[i].mes_n = b[2].jogadores[i].mes_n;
        no_2 -> jogadores_1[i].ano_n = b[2].jogadores[i].ano_n;
        no_2 -> jogadores_1[i].altura = b[2].jogadores[i].altura;
        no_2 -> jogadores_1[i].peso = b[2].jogadores[i].peso;
        no_2 -> jogadores_1[i].numero_da_camisola = b[2].jogadores[i].numero_da_camisola;
      }

      for (int i = 0; i < 20; i++)
      {
        no_2 -> jogadores_2[i].dia_n = b[3].jogadores[i].dia_n;
        no_2 -> jogadores_2[i].mes_n = b[3].jogadores[i].mes_n;
        no_2 -> jogadores_2[i].ano_n = b[3].jogadores[i].ano_n;
        no_2 -> jogadores_2[i].altura = b[3].jogadores[i].altura;
        no_2 -> jogadores_2[i].peso = b[3].jogadores[i].peso;
        no_2 -> jogadores_2[i].numero_da_camisola = b[3].jogadores[i].numero_da_camisola;
      }

      do
      {
        printf("Resultado do segundo jogo (RR-RR): ");
        scanf("%d-%d", &no_2 -> resultado_A, &no_2 -> resultado_B);
        fflush(stdin);

        if (no_2 -> resultado_A == no_2 -> resultado_B)
          printf("O resultado resulta em um epate, tente outra vez\n");
        else
        {
          printf("\nData do segundo jogo (DD/MM/AAAA): ");
          scanf("%d/%d/%d", &no_2 -> dia_j, &no_2 -> mes_j, &no_2 -> ano_j);
          fflush(stdin);

          printf("\nHora do segundo jogo (HH:MM): ");
          scanf("%d:%d", &no_2 -> horas, &no_2 -> minutos);
          fflush(stdin);
        }
      }
      while (no_2 -> resultado_A == no_2 -> resultado_B);

      no_2 -> prox = no_5;

      if (no_2 -> resultado_A > no_2 -> resultado_B)
      {
        strcpy(no_5 -> nome_equipa_2, no_2 -> nome_equipa_1);

        for (int i = 0; i < 20; i++)
        {
          no_5 -> jogadores_2[i].dia_n = no_2 -> jogadores_1[i].dia_n;
          no_5 -> jogadores_2[i].mes_n = no_2 -> jogadores_1[i].mes_n;
          no_5 -> jogadores_2[i].ano_n = no_2 -> jogadores_1[i].ano_n;
          no_5 -> jogadores_2[i].altura = no_2 -> jogadores_1[i].altura;
          no_5 -> jogadores_2[i].peso = no_2 -> jogadores_1[i].peso;
          no_5 -> jogadores_2[i].numero_da_camisola = no_2 -> jogadores_1[i].numero_da_camisola;
        }
      }
      else
      {
        strcpy(no_5 -> nome_equipa_2, no_2 -> nome_equipa_2);

        for (int i = 0; i < 20; i++)
        {
          no_5 -> jogadores_2[i].dia_n = no_2 -> jogadores_2[i].dia_n;
          no_5 -> jogadores_2[i].mes_n = no_2 -> jogadores_2[i].mes_n;
          no_5 -> jogadores_2[i].ano_n = no_2 -> jogadores_2[i].ano_n;
          no_5 -> jogadores_2[i].altura = no_2 -> jogadores_2[i].altura;
          no_5 -> jogadores_2[i].peso = no_2 -> jogadores_2[i].peso;
          no_5 -> jogadores_2[i].numero_da_camisola = no_2 -> jogadores_2[i].numero_da_camisola;
        }
      }
    }
    else
    {
      if(contador == 5)
      {
        //Terceiro jogo (Quartos de final)
        strcpy(no_3 -> nome_equipa_1, b[4].nome_da_equipa);
        strcpy(no_3 -> nome_equipa_2, b[5].nome_da_equipa);
        strcpy(no_3 -> jogadores_1[0].nome, b[4].jogadores[0].nome);
        strcpy(no_3 -> jogadores_2[0].nome, b[5].jogadores[0].nome);

        for (int i = 0; i < 20; i++)
        {
          no_3 -> jogadores_1[i].dia_n = b[4].jogadores[i].dia_n;
          no_3 -> jogadores_1[i].mes_n = b[4].jogadores[i].mes_n;
          no_3 -> jogadores_1[i].ano_n = b[4].jogadores[i].ano_n;
          no_3 -> jogadores_1[i].altura = b[4].jogadores[i].altura;
          no_3 -> jogadores_1[i].peso = b[4].jogadores[i].peso;
          no_3 -> jogadores_1[i].numero_da_camisola = b[4].jogadores[i].numero_da_camisola;
        }

        for (int i = 0; i < 20; i++)
        {
          no_3 -> jogadores_2[i].dia_n = b[5].jogadores[i].dia_n;
          no_3 -> jogadores_2[i].mes_n = b[5].jogadores[i].mes_n;
          no_3 -> jogadores_2[i].ano_n = b[5].jogadores[i].ano_n;
          no_3 -> jogadores_2[i].altura = b[5].jogadores[i].altura;
          no_3 -> jogadores_2[i].peso = b[5].jogadores[i].peso;
          no_3 -> jogadores_2[i].numero_da_camisola = b[5].jogadores[i].numero_da_camisola;
        }

        do
        {
          printf("Resultado do terceiro jogo (RR-RR): ");
          scanf("%d-%d", &no_3 -> resultado_A, &no_3 -> resultado_B);
          fflush(stdin);

          if (no_3 -> resultado_A == no_3 -> resultado_B)
            printf("O resultado resulta em um epate, tente outra vez\n");
          else
          {
            printf("\nData do terceiro  jogo (DD/MM/AAAA): ");
            scanf("%d/%d/%d", &no_3 -> dia_j, &no_3 -> mes_j, &no_3 -> ano_j);
            fflush(stdin);

            printf("\nHora do terceiro jogo (HH:MM): ");
            scanf("%d:%d", &no_3 -> horas, &no_3 -> minutos);
            fflush(stdin);
          }
        }
        while (no_3 -> resultado_A == no_3 -> resultado_B);

        no_3 -> prox = no_6;

        if (no_3 -> resultado_A > no_3 -> resultado_B)
        {
          strcpy(no_6 -> nome_equipa_1, no_3 -> nome_equipa_1);

          for (int i = 0; i < 20; i++)
          {
            no_6 -> jogadores_1[i].dia_n = no_3 -> jogadores_1[i].dia_n;
            no_6 -> jogadores_1[i].mes_n = no_3 -> jogadores_1[i].mes_n;
            no_6 -> jogadores_1[i].ano_n = no_3 -> jogadores_1[i].ano_n;
            no_6 -> jogadores_1[i].altura = no_3 -> jogadores_1[i].altura;
            no_6 -> jogadores_1[i].peso = no_3 -> jogadores_1[i].peso;
            no_6 -> jogadores_1[i].numero_da_camisola = no_3 -> jogadores_1[i].numero_da_camisola;
          }
        }
        else
        {
          strcpy(no_6 -> nome_equipa_1, no_3 -> nome_equipa_2);

          for (int i = 0; i < 20; i++)
          {
            no_6 -> jogadores_1[i].dia_n = no_3 -> jogadores_2[i].dia_n;
            no_6 -> jogadores_1[i].mes_n = no_3 -> jogadores_2[i].mes_n;
            no_6 -> jogadores_1[i].ano_n = no_3 -> jogadores_2[i].ano_n;
            no_6 -> jogadores_1[i].altura = no_3 -> jogadores_2[i].altura;
            no_6 -> jogadores_1[i].peso = no_3 -> jogadores_2[i].peso;
            no_6 -> jogadores_1[i].numero_da_camisola = no_3 -> jogadores_2[i].numero_da_camisola;
          }
        }
      }
      else
      {
        if (contador == 6)
        {
          //Quarto jogo (Quartos de final)
          strcpy(no_4 -> nome_equipa_1, b[6].nome_da_equipa);
          strcpy(no_4 -> nome_equipa_2, b[7].nome_da_equipa);
          strcpy(no_4 -> jogadores_1[0].nome, b[6].jogadores[0].nome);
          strcpy(no_4 -> jogadores_2[0].nome, b[7].jogadores[0].nome);

          for (int i = 0; i < 20; i++)
          {
            no_4 -> jogadores_1[i].dia_n = b[6].jogadores[i].dia_n;
            no_4 -> jogadores_1[i].mes_n = b[6].jogadores[i].mes_n;
            no_4 -> jogadores_1[i].ano_n = b[6].jogadores[i].ano_n;
            no_4 -> jogadores_1[i].altura = b[6].jogadores[i].altura;
            no_4 -> jogadores_1[i].peso = b[6].jogadores[i].peso;
            no_4 -> jogadores_1[i].numero_da_camisola = b[6].jogadores[i].numero_da_camisola;
          }

          for (int i = 0; i < 20; i++)
          {
            no_4 -> jogadores_2[i].dia_n = b[7].jogadores[i].dia_n;
            no_4 -> jogadores_2[i].mes_n = b[7].jogadores[i].mes_n;
            no_4 -> jogadores_2[i].ano_n = b[7].jogadores[i].ano_n;
            no_4 -> jogadores_2[i].altura = b[7].jogadores[i].altura;
            no_4 -> jogadores_2[i].peso = b[7].jogadores[i].peso;
            no_4 -> jogadores_2[i].numero_da_camisola = b[7].jogadores[i].numero_da_camisola;
          }

          do
          {
            printf("Resultado do quarto jogo (RR-RR): ");
            scanf("%d-%d", &no_4 -> resultado_A, &no_4 -> resultado_B);
            fflush(stdin);

            if (no_4 -> resultado_A == no_4 -> resultado_B)
              printf("O resultado resulta em um epate, tente outra vez\n");
            else
            {
              printf("\nData do quarto jogo (DD/MM/AAAA): ");
              scanf("%d/%d/%d", &no_4 -> dia_j, &no_4 -> mes_j, &no_4 -> ano_j);
              fflush(stdin);

              printf("\nHora do quarto jogo (HH:MM): ");
              scanf("%d:%d", &no_4 -> horas, &no_4 -> minutos);
              fflush(stdin);
            }
          }
          while (no_4 -> resultado_A == no_4 -> resultado_B);

          no_4 -> prox = no_6;

          if (no_4 -> resultado_A > no_4 -> resultado_B)
          {
            strcpy(no_6 -> nome_equipa_2, no_4 -> nome_equipa_1);

            for (int i = 0; i < 20; i++)
            {
              no_6 -> jogadores_2[i].dia_n = no_4 -> jogadores_1[i].dia_n;
              no_6 -> jogadores_2[i].mes_n = no_4 -> jogadores_1[i].mes_n;
              no_6 -> jogadores_2[i].ano_n = no_4 -> jogadores_1[i].ano_n;
              no_6 -> jogadores_2[i].altura = no_4 -> jogadores_1[i].altura;
              no_6 -> jogadores_2[i].peso = no_4 -> jogadores_1[i].peso;
              no_6 -> jogadores_2[i].numero_da_camisola = no_4 -> jogadores_1[i].numero_da_camisola;
            }
          }
          else
          {
            strcpy(no_6 -> nome_equipa_2, no_4 -> nome_equipa_2);

            for (int i = 0; i < 20; i++)
            {
              no_6 -> jogadores_2[i].dia_n = no_4 -> jogadores_2[i].dia_n;
              no_6 -> jogadores_2[i].mes_n = no_4 -> jogadores_2[i].mes_n;
              no_6 -> jogadores_2[i].ano_n = no_4 -> jogadores_2[i].ano_n;
              no_6 -> jogadores_2[i].altura = no_4 -> jogadores_2[i].altura;
              no_6 -> jogadores_2[i].peso = no_4 -> jogadores_2[i].peso;
              no_6 -> jogadores_2[i].numero_da_camisola = no_4 -> jogadores_2[i].numero_da_camisola;
            }
          }
        }
        else
        {
          if (contador == 7)
          {
            //Quinto jogo (Meias finais)
            do
              {
              printf("Resultado do quinto jogo (RR-RR): ");
              scanf("%d-%d", &no_5 -> resultado_A, &no_5 -> resultado_B);
              fflush(stdin);

              if (no_5 -> resultado_A == no_5 -> resultado_B)
                printf("O resultado resulta em um epate, tente outra vez\n");
              else
              {
                printf("\nData do quinto jogo (DD/MM/AAAA): ");
                scanf("%d/%d/%d", &no_5 -> dia_j, &no_5 -> mes_j, &no_5 -> ano_j);
                fflush(stdin);

                printf("\nHora do quinto jogo (HH:MM): ");
                scanf("%d:%d", &no_5 -> horas, &no_5 -> minutos);
                fflush(stdin);
              }
            }
            while (no_5 -> resultado_A == no_5 -> resultado_B);

            no_5 -> prox = no_7;

            if (no_5 -> resultado_A > no_5 -> resultado_B)
            {
              strcpy(no_7 -> nome_equipa_1, no_5 -> nome_equipa_1);

              for (int i = 0; i < 20; i++)
              {
                no_7 -> jogadores_1[i].dia_n = no_5 -> jogadores_1[i].dia_n;
                no_7 -> jogadores_1[i].mes_n = no_5 -> jogadores_1[i].mes_n;
                no_7 -> jogadores_1[i].ano_n = no_5 -> jogadores_1[i].ano_n;
                no_7 -> jogadores_1[i].altura = no_5 -> jogadores_1[i].altura;
                no_7 -> jogadores_1[i].peso = no_5 -> jogadores_1[i].peso;
                no_7 -> jogadores_1[i].numero_da_camisola = no_5 -> jogadores_1[i].numero_da_camisola;
              }
            }
            else
            {
              strcpy(no_7 -> nome_equipa_1, no_5 -> nome_equipa_2);

              for (int i = 0; i < 20; i++)
              {
                no_7 -> jogadores_1[i].dia_n = no_5 -> jogadores_2[i].dia_n;
                no_7 -> jogadores_1[i].mes_n = no_5 -> jogadores_2[i].mes_n;
                no_7 -> jogadores_1[i].ano_n = no_5 -> jogadores_2[i].ano_n;
                no_7 -> jogadores_1[i].altura = no_5 -> jogadores_2[i].altura;
                no_7 -> jogadores_1[i].peso = no_5 -> jogadores_2[i].peso;
                no_7 -> jogadores_1[i].numero_da_camisola = no_5 -> jogadores_2[i].numero_da_camisola;
              }
            }
          }
          else
          {
            if (contador == 8)
            {
              //Sexto jogo (Meias finais)
              do
              {
                printf("Resultado do sexto jogo (RR-RR): ");
                scanf("%d-%d", &no_6 -> resultado_A, &no_6 -> resultado_B);
                fflush(stdin);

                if (no_6 -> resultado_A == no_6 -> resultado_B)
                  printf("O resultado resulta em um epate, tente outra vez\n");
                else
                {
                  printf("\nData do sexto jogo (DD/MM/AAAA): ");
                  scanf("%d/%d/%d", &no_6 -> dia_j, &no_6 -> mes_j, &no_6 -> ano_j);
                  fflush(stdin);

                  printf("\nHora do sexto jogo (HH:MM): ");
                  scanf("%d:%d", &no_6 -> horas, &no_6 -> minutos);
                  fflush(stdin);
                }
              }
              while (no_6 -> resultado_A == no_6 -> resultado_B);

              no_6 -> prox = no_7;

              if (no_6 -> resultado_A > no_6 -> resultado_B)
              {
                strcpy(no_7 -> nome_equipa_2, no_6 -> nome_equipa_1);

                for (int i = 0; i < 20; i++)
                {
                  no_7 -> jogadores_2[i].dia_n = no_6 -> jogadores_1[i].dia_n;
                  no_7 -> jogadores_2[i].mes_n = no_6 -> jogadores_1[i].mes_n;
                  no_7 -> jogadores_2[i].ano_n = no_6 -> jogadores_1[i].ano_n;
                  no_7 -> jogadores_2[i].altura = no_6 -> jogadores_1[i].altura;
                  no_7 -> jogadores_2[i].peso = no_6 -> jogadores_1[i].peso;
                  no_7 -> jogadores_2[i].numero_da_camisola = no_6 -> jogadores_1[i].numero_da_camisola;
                }
              }
              else
              {
                strcpy(no_7 -> nome_equipa_2, no_6 -> nome_equipa_2);

                for (int i = 0; i < 20; i++)
                {
                  no_7 -> jogadores_2[i].dia_n = no_6 -> jogadores_2[i].dia_n;
                  no_7 -> jogadores_2[i].mes_n = no_6 -> jogadores_2[i].mes_n;
                  no_7 -> jogadores_2[i].ano_n = no_6 -> jogadores_2[i].ano_n;
                  no_7 -> jogadores_2[i].altura = no_6 -> jogadores_2[i].altura;
                  no_7 -> jogadores_2[i].peso = no_6 -> jogadores_2[i].peso;
                  no_7 -> jogadores_2[i].numero_da_camisola = no_6 -> jogadores_2[i].numero_da_camisola;
                }
              }
            }
            else
            {
              if (contador == 9)
              {
                //Setimo jogo (Final)
                do
                {

                  printf("Resultado do setimo jogo (RR-RR): ");
                  scanf("%d-%d", &no_7 -> resultado_A, &no_7 -> resultado_B);
                  fflush(stdin);

                  if (no_7 -> resultado_A == no_7 -> resultado_B)
                    printf("O resultado resulta em um epate, tente outra vez\n");
                  else
                  {
                    printf("\nData do setimo jogo (DD/MM/AAAA): ");
                    scanf("%d/%d/%d", &no_7 -> dia_j, &no_7 -> mes_j, &no_7 -> ano_j);
                    fflush(stdin);

                    printf("\nHora do setimo jogo (HH:MM): ");
                    scanf("%d:%d", &no_7 -> horas, &no_7 -> minutos);
                    fflush(stdin);
                  }
                }
                while (no_7 -> resultado_A == no_7 -> resultado_B);

                no_7 -> prox = no_8;

                if (no_7 -> resultado_A > no_7 -> resultado_B)
                {
                  strcpy(no_8 -> nome_equipa_1, no_7 -> nome_equipa_1);
                  for (int i = 0; i < 20; i++)
                  {
                    no_8 -> jogadores_1[i].dia_n = no_6 -> jogadores_1[i].dia_n;
                    no_8 -> jogadores_1[i].mes_n = no_6 -> jogadores_1[i].mes_n;
                    no_8 -> jogadores_1[i].ano_n = no_6 -> jogadores_1[i].ano_n;
                    no_8 -> jogadores_1[i].altura = no_6 -> jogadores_1[i].altura;
                    no_8 -> jogadores_1[i].peso = no_6 -> jogadores_1[i].peso;
                    no_8 -> jogadores_1[i].numero_da_camisola = no_6 -> jogadores_1[i].numero_da_camisola;
                  }
                }
                else
                {
                  strcpy(no_8 -> nome_equipa_1, no_7 -> nome_equipa_2);
                  for (int i = 0; i < 20; i++)
                  {
                    no_8 -> jogadores_1[i].dia_n = no_7 -> jogadores_2[i].dia_n;
                    no_8 -> jogadores_1[i].mes_n = no_7 -> jogadores_2[i].mes_n;
                    no_8 -> jogadores_1[i].ano_n = no_7 -> jogadores_2[i].ano_n;
                    no_8 -> jogadores_1[i].altura = no_7 -> jogadores_2[i].altura;
                    no_8 -> jogadores_1[i].peso = no_7 -> jogadores_2[i].peso;
                    no_8 -> jogadores_1[i].numero_da_camisola = no_7 -> jogadores_2[i].numero_da_camisola;
                  }
                }
                no_8 -> prox = NULL;
                printf("Equipa vencedora: %s\n", no_8 -> nome_equipa_1);
              }
            }
          }
        }
      }
    }
  }
}

void escrever_equipas(equipa equipas[TAM_T_A])
{
  //Primeiro jogo (Quartos de final)
  plista no_1 = (plista)malloc(sizeof(jogo));

  //Segundo jogo (Quartos de final)
  plista no_2 = (plista)malloc(sizeof(jogo));

  //Terceiro jogo (Quartos de final)
  plista no_3 = (plista)malloc(sizeof(jogo));

  //Quarto jogo (Quartos de final)
  plista no_4 = (plista)malloc(sizeof(jogo));

  //Quinto jogo (Meias finais)
  plista no_5 = (plista)malloc(sizeof(jogo));

  //Sexto jogo (Meias finais)
  plista no_6 = (plista)malloc(sizeof(jogo));

  //Setimo jogo (Final)
  plista no_7 = (plista)malloc(sizeof(jogo));

  //Equipa Vencedora do torneio
  plista no_8 = (plista)malloc(sizeof(jogo));

  if (contador_jogo >= 1)
  {
      printf("Equipa 1 (jogo 1): %s\n", no_1 -> nome_equipa_1);
      printf("Equipa 2 (jogo 1): %s\n", no_1 -> nome_equipa_2);
      printf("Resultado (jogo 1): %d-%d\n", no_1 -> resultado_A, no_1 -> resultado_B);
  }

  if (contador_jogo > 2)
  {
    printf("Equipa 3 (jogo 2): %s\n", no_2 -> nome_equipa_1);
    printf("Equipa 4 (jogo 2): %s\n", no_2 -> nome_equipa_2);
    printf("Resultado (jogo 2): %d-%d\n", no_2 -> resultado_A, no_2 -> resultado_B);
  }

  if(contador_jogo > 3)
  {
    printf("Equipa 5 (jogo 3): %s\n", no_3 -> nome_equipa_1);
    printf("Equipa 6 (jogo 3): %s\n", no_3 -> nome_equipa_2);
    printf("Resultado (jogo 3): %d-%d\n", no_3 -> resultado_A, no_3 -> resultado_B);
  }

  if(contador_jogo > 4)
  {
    printf("Equipa 7 (jogo 4): %s\n", no_4 -> nome_equipa_1);
    printf("Equipa 8 (jogo 4): %s\n", no_4 -> nome_equipa_2);
    printf("Resultado (jogo 4): %d-%d\n", no_4 -> resultado_A, no_4 -> resultado_B);
  }

  if(contador_jogo > 5)
  {
    printf("Equipa vencedora do jogo 1 (jogo 5): %s\n", no_5 -> nome_equipa_1);
    printf("Equipa vencedora do jogo 2 (jogo 5): %s\n", no_5 -> nome_equipa_2);
    printf("Resultado (jogo 5): %d-%d\n", no_5 -> resultado_A, no_5 -> resultado_B);
  }

  if(contador_jogo > 6)
  {
    printf("Equipa vencedora do jogo 3 (jogo 6): %s\n", no_6 -> nome_equipa_1);
    printf("Equipa vencedora do jogo 4 (jogo 6): %s\n", no_6 -> nome_equipa_2);
    printf("Resultado (jogo 6): %d-%d\n", no_6 -> resultado_A, no_6 -> resultado_B);
  }

  if(contador_jogo > 7)
  {
    printf("Equipa vencedora do jogo 5 (jogo 7): %s\n", no_7 -> nome_equipa_1);
    printf("Equipa vencedora do jogo 6 (jogo 7): %s\n", no_7 -> nome_equipa_2);
    printf("Resultado (jogo 7): %d-%d\n", no_7 -> resultado_A, no_7 -> resultado_B);
  }

  if(contador_jogo > 8)
    printf("Equipa vencedora do torneio: %s\n", no_8 -> nome_equipa_1);
}

void retangulo_p_b_c()
{
  char linha = 205; // caractere especial retirado da tablela ASCII
  //parte de baixo
  printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c", linha);printf("%c\n", linha);
}

void sair()
{
  char opcao;

  printf("Tem a certeza que quer sair (s/n): ");
  fflush(stdin);
  scanf("%c", &opcao);
  if ( (opcao == 's') || (opcao == 'S') )
  {
    printf("A sair...");
    exit(9);
  }
}

void menu(equipa equipas[TAM_T_A], jogador jogadores[TAM_T])
{
  int opcao;
  char linha = 205; // caractere especial retirado da tablela ASCII
  do
  {
    retangulo_p_b_c();
    printf("\t\tMENU\t\t\n");
    printf("1 - Inserir nome das equipas\t\n");
    printf("2 - Ler os ficheiros dos jogadores e colocar as equipas aleatoriamente\t\n");
    printf("3 - Inserir dados do jogo %d\t\n", contador_jogo);
    printf("4 - Ver jogos ja disputados\t\n");
    printf("5 - Sair\t\n");
    retangulo_p_b_c();
    printf("Opcao -> ");
    scanf("%d", &opcao);
    switch(opcao)
    {
      case 1: if (contador == 1)
              {
                nome_das_equipas(equipas);
                contador = contador + 1; break;
              }
              else
                printf("Ja inseriu as equipas.\n"); break;
      case 2: if (contador == 2)
              {
                ler_dados(equipas);
                escrever_aleatorio(equipas);
                contador = contador + 1;
              }
              else
                printf("Passo ja executado ou insira as equipas primeiro antes de seguir para este passo.\n"); break;

      case 3: if ((contador >= 3) && (contador <=9))
              {
                torneio(equipas);
                contador = contador + 1;
                contador_jogo = contador_jogo + 1;
              }
              else
              {
                if(contador > 9)
                  printf("O torneio ja terminou\n");
                else
                  printf("Leia os ficheiros primeiro antes de seguir para este passo.\n");
              }break;

      case 4: if(contador >= 4)
                escrever_equipas(equipas);
              else
                printf("Insira o primeiro jogo primeiro antes de seguir para este passo.\n");
              break;

      case 5: sair(); break;
      default: printf("Opcao invalida, tente novamente uma das opcoes apresentadas.\n");
    }
  }
  while (1);
}

int main()
{
  //tabelas das estruturas
  equipa equipas[TAM_T_A];
  jogador jogadores[TAM_T];

  plista lista = NULL;// declara a lista vazia

  //menu do programa
  menu(equipas, jogadores);

  return 1;
}
