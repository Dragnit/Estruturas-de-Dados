#include <stdio.h>
#include <math.h>
#include <stdlib.h>

struct fracao{

  float num;
  float den;
  float num1;
  float den1;

};

typedef struct fracao frac;

void ler_fracao(frac fra){


    printf("Primeira fracao: %f/%f ",fra.num,fra.den);

    printf("Segunda fracao: %f/%f",fra.num1,fra.den1 );
}

float soma_fracao(){
  frac fra;
  float result;

    result = ((fra.num * fra.den1) + (fra.num1 * fra.den)) / (fra.den * fra.den1);

  return result;
}
float sub_fracao(){
  frac fra;
  float result;

    result = ((fra.num * fra.den1) - (fra.num1 * fra.den)) / (fra.den * fra.den1);

  return result;
}

float mult_fracao(){
  frac fra;
  float result;

    result = (fra.num * fra.num1) / (fra.den * fra.den1);

  return result;
}

float divisao_fracao(){
  frac fra;
  float result;

    result = (fra.num * fra.den1) / (fra.num1 * fra.den);

  return result;
}
float valor_real_fracao(){
  frac fra;
  float result;

    result = fra.num / fra.den;

  return result;
}
float potenc_fracao(frac fra,int expo){

  float result;

    result = pow(fra.num, expo) / pow(fra.den, expo);

  return result;
}


int main(){
  frac fra;
  float result;

    printf("Digite uma fracao no formato numerador/denominador\n");
    scanf("%f/%f", &fra.num, &fra.den);
    if(fra.den == 0){
      printf("Fracao Invalida");
      exit(0);
    }
    scanf("%f/%f",&fra.num1,&fra.den1);
    if(fra.num1 == 0){
      printf("Fracao Invalida");
      exit(0);
    }
    ler_fracao(fra);

    //result = mult_fracao();
    //printf("Resultado mult: %f\n", result);
    //result = soma_fracao();
    //printf("Resultado Soma: %f\n", result);
    //result = sub_fracao();
    //printf("Resultado Sub: %f\n", result);
    //result = divisao_fracao();
    //printf("Resultado divisao: %f\n", result);
    //result = valor_real_fracao();
    //printf("Resultado valor real: %f\n", result);
    result = potenc_fracao(fra, 3);
    printf("Resultado pontencia: %f\n", result);
}
