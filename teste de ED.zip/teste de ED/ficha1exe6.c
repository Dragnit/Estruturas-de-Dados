#include <stdio.h>
#include <stdlib.h>


void lerMatriz(int vector[5][5]){

  for(int i = 0; i < 5 ;i++)
        for(int j = 0; j < 5 ; j++)
              vector[i][j]= rand() % 50 + 1;
}


void escreveMatriz(int vector[5][5]){
  printf("Matriz\n" );
  for(int i = 0; i < 5 ;i++){
        for(int j = 0; j < 5 ; j++){
              printf("%2.0d ",vector[i][j]);
        }
        printf("\n");
  }
}

void calculaMedia(int vector[5][5]){
  int num = 0, numElementos = 0;

  for(int i =0 ; i < 5 ; i++){
      for(int j = 0; j < 5 ; j++){
        num+= vector[i][j];
        numElementos++;
      }
  }
  printf("\nMedia: %0.2f\n", (1.0*num)/numElementos);
}

void calculaMediaColuna(int vector[5][5], int n){
  int num = 0, numElementos = 0;

  for(int i =0 ; i < 5 ; i++){
      for(int j = 0; j < 5 ; j++){
        if(j== n-1){
          num+= vector[i][j];
          numElementos++;
        }
      }
  }
  printf("\nMedia: %0.2f\n", (1.0*num)/numElementos);
}

void calculaMediaLinha(int vector[5][5], int n){
  int num = 0, numElementos = 0;
  int j = 0;

  for(int i =0 ; i < 5 ; i++){
    if(i == n-1){
      for(j = 0; j < 5 ; j++){
          num+= vector[i][j];
          numElementos++;
        }
      }
  }
  printf("\nMedia: %0.2f\n", (1.0*num)/numElementos);
}

void numZeros(int vector[5][5]){

  int numElementos = 0;
  int j = 0;
  for(int i =0 ; i < 5 ; i++){
      for( j = i+1 ; j < 5 ; j++){
          if(vector[i][j] == 0)
              numElementos++;
      }
  }
  printf("\nNumero de zeros: %d\n", numElementos);
}

void calculaLinha(int vector[5][5]){
  int num1 = 0, num2 = 0, linha = 0;

  for(int i = 0 ; i < 5 ; i++){
              num1 = 0;
      for(int j = 0; j < 5 ; j++){

          num1+= vector[i][j];
        }
        if(num1 >= num2){
          linha = i+1;
          num2=num1;
        }
      }
  printf("\nA maior linha e: %d\n", linha);
}

void trocaColuna(float vector[5][5], int c1 , int c2){

  float aux=0;
  if(j>=0 && j < n && k >= 0 && k < n)
    for(int i =0 ; i < 5 ; i++){
      aux=vector[i][c1-1];
      vector[i][c1-1]=vector[i][c2-1];
      vector[i][c2-1]=aux;
    }
  }

void somaMatriz(int vectorA[5][5], int vectorB[5][5]){
  int vectorC[5][5];

  for(int i = 0; i < 5 ;i++){
        for(int j = 0; j < 5 ; j++){
              vectorC[i][j]=vectorA[i][j]+=vectorB[i][j];
        }
  }
  printf("Resultado\n");
  for(int i = 0; i < 5 ;i++){
        for(int j = 0; j < 5 ; j++){
              printf("%d ",vectorC[i][j]);
        }
        printf("\n");
  }
}




int main(){
  int n = 5;
  int vectorA[5][5];
  int vectorB[5][5];

    lerMatriz(vectorA);
    lerMatriz(vectorB);
    escreveMatriz(vectorA);
    escreveMatriz(vectorB);
    //calculaMedia(vector);
    //calculaMediaColuna(vector,n);
    //calculaMediaLinha(vector,n);
    //numZeros(vector);
    //calculaLinha(vector);
    //trocaColuna(vector,2,3);
    //escreveMatriz(vector);
    somaMatriz(vectorA,vectorB);
}
