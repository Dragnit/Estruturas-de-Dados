#include <stdio.h>
#include <stdlib.h>


void criaCrescente(int n){

  char nomeFicheiro[50];
  sprintf(nomeFicheiro, "crescente%d.txt",n);

  FILE * file=fopen(nomeFicheiro, "w");

  if(file != NULL)
    for(int i =0; i <= n; i++)
      fprintf(file,"%d ",i);
    else
      printf("Ocorreu um erro na abertura do ficheiro");
    fclose(file);
}

void criaDecrescente(int n){

  char nomeFicheiro[50];
  sprintf(nomeFicheiro, "decrescente%d.txt",n);

  FILE * file=fopen(nomeFicheiro, "w");

  if(file != NULL)
    for(int i =0; i >= n; n--)
      fprintf(file,"%d ",n);
    else
      printf("Ocorreu um erro na abertura do ficheiro");
    fclose(file);
}

void criaAleatorio(int n){
  int a = 0;
  char nomeFicheiro[50];
  sprintf(nomeFicheiro, "aleatorio%d.txt",n);

  FILE * file=fopen(nomeFicheiro, "w");

  if(file != NULL)
    for(int i = 0; i <= n; i++){
      a = rand() % n;
      fprintf(file,"%d ",a);
    }
    else
      printf("Ocorreu um erro na abertura do ficheiro");
    fclose(file);
}

void criaComplexo(){
  int num=0;

  FILE * file1= fopen("aleatorio.txt","a");

  FILE * file2= fopen("aleatorio100.txt","r");

    if(file2!=NULL)
      for(int i =0; i <= 50; i++){
        fscanf(file2,"%d ",&num);
        fprintf(file1,"%d ",num);
      }
    else
      printf("Erro ao abrir o ficheiro");
    fclose(file2);

    FILE * file3= fopen("aleatorio500.txt","r");

      if(file3!=NULL)
        for(int i = 0; i <= 100; i++){
          fscanf(file3,"%d", &num);
          fprintf(file1,"%d ",num);
        }
      else
        printf("Erro ao abrir o ficheiro");
      fclose(file3);

      FILE * file4= fopen("aleatorio1000.txt","r");

        if(file4!=NULL)
          for(int i =0; i <= 500; i++){
            fscanf(file4,"%d ", &num);
            fprintf(file1,"%d ",num);
          }
        else
          printf("Erro ao abrir o ficheiro");
        fclose(file4);
        fclose(file1);

}

void analisaFicheiro(){
  int num=0;
  int par = 0;
  int impar=0;

  FILE * file= fopen("aleatorio.txt","r");
  FILE * file2= fopen("par.txt","a");
  FILE * file3= fopen("impar.txt","a");

  if(file!=NULL)
    for(int i =0; i <= 650; i++){
      fscanf(file,"%d ", &num);
      if(num % 2 == 0){
        fprintf(file2,"%d ", num);
        par++;
      }
      else{
        fprintf(file3,"%d ", num);
        impar++;
      }

    }
    else
      printf("Erro ao abrir o ficheiro");
    fclose(file);
    fclose(file2);
    fclose(file3);

    printf("Numeros pares: %d \nNumeros impares: %d\n",par, impar);
}


int main(){

analisaFicheiro();

}
