#include <stdio.h>

void troca(int *i,int *j)
{
  int aux;

  aux = *i;
  *i = *j;
  *j = aux;
}
void troca_2(int *i,int *j)
{
  int *aux;

  aux = i;
  i = j;
  j = aux;
}
void troca_3(int *i,int *j)
{
  int aux;

  aux = *i;
  *i = *j;
  *j = aux;
}
void escrever(int a,int b)
{
  printf("a = %i,b = %i\n",a,b);

}
int main()
{
  int a = 3,b = 4;
  unsigned long int  i,j;

  i = &a;
  j = &b;
  escrever(a,b);
  //troca(i,j);
  //troca_2(i,j);
  troca_3(i,j);
  escrever(a,b);


	return 0;
}
