#include <stdio.h>
#include <stdlib.h>

typedef struct no * pfila;

typedef struct no
{
  float uele;
  pfila FirstInFirstOut;
}fila;

pfila cria_fila()
{
  pfila p = NULL;
  return p;
}

int fila_vazia(pfila p)
{
  if(p == NULL)
  {
    return 1;
  }
  else
  {
    return 0;
  }
}

void escreve_lista(pfila p)
{
  if(fila_vazia(p))
  {
    printf("A lista esta vazia\n");
  }
  else
  {
    printf("[");

    do
    {
      printf(" %.2f,",p -> uele);
      p = p -> FirstInFirstOut;

    }while(p != NULL);
    printf("\b ]\n");
  }
}

void inserir_fila_fim(pfila p,float x)
{
  pfila re = (pfila)malloc(sizeof(fila));//criar uma caixinha com espaco

  if(re == NULL)
  {
    perror("Erro!!!");
  }
  else
  {
    re -> uele = x;
    re -> FirstInFirstOut = NULL;

    if(fila_vazia(p))
    {
      *p = re;
    }
    else
    {
      pfila aux = *p;

      while(aux -> FirstInFirstOut != NULL)
      {
        aux = aux -> FirstInFirstOut;
      }
      aux -> FirstInFirstOut = re;
    }
  }
}

int main()
{
  pfila pl = cria_fila();

  escreve_lista(pl);

  inserir_fila_fim(&pl,3.2);

  escreve_lista(pl);

	return 0;
}
