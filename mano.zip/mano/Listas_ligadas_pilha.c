#include <stdio.h>
#include <stdlib.h>

typedef struct no * ppilha;

typedef struct no
{
  float stack;
  ppilha LastInFirstOut;
}pilha;

ppilha cria_pilha()
{
  ppilha p = NULL;
  return p;
}

int pilha_vazia(ppilha p)
{
  if(p == NULL)
  {
    return 1;
  }
  else
  {
    return 0;
  }
}

void escreve_lista(ppilha p)
{
  if(pilha_vazia(p))
  {
    printf("Lista vazia\n");
  }
  else
  {
    printf("[");

    do
    {
      printf(" %.2f,",p -> stack);
      p = p -> LastInFirstOut;

    }while(p != NULL);
    printf("\b ]\n");
  }
}

void inserir_pilha(ppilha * p, float x)
{
  ppilha esp = (ppilha)malloc(sizeof(pilha));

  if(esp == NULL)
  {
    perror("Erro!!!");
  }
  else
  {
    esp -> stack = x;
    esp -> LastInFirstOut = NULL;

    if(pilha_vazia(*p))
    {
      *p = esp;
    }
    else
    {
      ppilha aux = *p;

      while(aux -> LastInFirstOut != NULL)
      {
        aux = aux -> LastInFirstOut;
      }
      aux -> LastInFirstOut = esp;
    }
  }
}

void retirar_pilha(ppilha * p)
{
  ppilha esp = (ppilha)malloc(sizeof(pilha));

  if(esp == NULL)
  {
    perror("Erro!!!");
  }
  else
  {
    if(pilha_vazia(*p))
    {
      printf("Lista vazia");
    }
    else
    {
      ppilha aux = *p;
      ppilha aux2 = NULL;

      while(aux -> LastInFirstOut != NULL)
      {
        aux2 = aux;
        aux = aux -> LastInFirstOut;
      }
      aux2 -> LastInFirstOut = NULL;
      free(aux);
    }
  }
}

void mostrar_ultimo_elemento(ppilha * p)
{
  if(pilha_vazia(*p))
  {
    printf("Lista vazia");
  }
  else
  {
    ppilha aux = *p;
    while(aux -> LastInFirstOut != NULL)
    {
      aux = aux -> LastInFirstOut;
    }
    printf("Elemento no topo do Stack: %.2f\n",aux -> stack);
  }
}

int main()
{
  ppilha pl = cria_pilha();

  escreve_lista(pl);

  inserir_pilha(&pl,2.8);
  inserir_pilha(&pl,32);
  inserir_pilha(&pl,1);

  escreve_lista(pl);

  retirar_pilha(&pl);

  escreve_lista(pl);

  mostrar_ultimo_elemento(&pl);

  escreve_lista(pl);
	return 0;
}
