#include <stdio.h>

float fatorialIt(int n)
{
  float p = 1;

  for(int i = 1;i <= n;i++)
  {
    p = p*i;
  }
  return p;
}

float fatorialRec(int n)
{
  if(n == 1)
  return 1;
  else
  return n*fatorialRec(n-1);
}

int main()
{
  int n = 3;
  float p;

  printf("IT: %.1f\n",p = fatorialIt(n));
  printf("REC: %.1f",p = fatorialRec(n));


	return 0;
}
