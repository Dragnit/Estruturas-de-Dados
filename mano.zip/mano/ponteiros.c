#include <stdio.h>
#include <stdlib.h>

void tamanho()
{
  int *point,*point2,*point3;

  printf("| tipo | tamanho (bytes) | tamanho do ponteiro (bytes)\n");
  printf("+------+-------------------+------------------------------+\n");
  printf("| char |              %i |                          %i |\n\n",sizeof(char),sizeof(*point));

  printf("| tipo | tamanho (bytes) | tamanho do ponteiro (bytes)\n");
  printf("+------+-------------------+------------------------------+\n");
  printf("| int |              %i |                           %i |\n\n",sizeof(int),sizeof(*point2));

  printf("| tipo | tamanho (bytes) | tamanho do ponteiro (bytes)\n");
  printf("+------+-------------------+------------------------------+\n");
  printf("| float |              %i |                         %i |\n\n",sizeof(float),sizeof(*point3));
}
int main()
{
	int a = 2,b = 3;
  int *p,*q;

  p = &a;
  q = &b;

  //printf("%p %u %u %d %d %d %d\n",p,p,&p,*p+4,**&p,5**p,**&p+6);

  tamanho();

	return 0;
}
