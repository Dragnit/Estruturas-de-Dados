#include <stdio.h>
#include <stdlib.h>

typedef struct lno * plista;

typedef struct lno
{
  float valor;
  plista prox;

}lista_no;


plista cria_lista()
{
  plista p = NULL;
  return p;
}

int lista_vazia(plista lst)
{
  if(lst == NULL)
  {
    return 1;
  }
  else
  {
    return 0;
  }
}

void escreve_lista(plista lst)
{
  if(lista_vazia(lst))
  {
    printf("A lista esta vazia\n");
  }
  else
  {
    printf("[");

    do
    {
      printf(" %.2f,",lst -> valor);
      lst = lst -> prox;

    }while(lst != NULL);
    printf("\b ]\n");
  }
}

void junta_no_ini_lista(float x,plista * lst)
{
  plista no = (plista)malloc(sizeof(lista_no));

  if(no == NULL)
  {
    perror("Erro!!!");
  }
  else
  {
    no -> valor = x;
    no -> prox = *lst;
    *lst = no;
  }
}

void junta_no_fim_lista(float x,plista * lst)
{
  plista no = (plista)malloc(sizeof(lista_no));//criar uma caixinha com espaco

  if(no == NULL)
  {
    perror("Erro!!!");
  }
  else
  {
    no -> valor = x;
    no -> prox = NULL;

    if(lista_vazia(*lst))
    {
      *lst = no;
    }
    else
    {
      plista aux = *lst;

      while(aux -> prox != NULL)
      {
        aux = aux -> prox;
      }
      aux -> prox = no;
    }
  }
}

void remover_no_ini_lista(plista *lst)
{
  plista no = (plista)malloc(sizeof(lista_no));

  if(no == NULL)
  {
    perror("Erro!!!");
  }
  else
  {
    if(lista_vazia(*lst))
    {
      printf("Lista vazia");
    }
    else
    {
    no = *lst;
    *lst = no -> prox;
    free(no);
    }
  }
}

void remover_no_fim_lista(plista *lst)
{
  plista no = (plista)malloc(sizeof(lista_no));

  if(no == NULL)
  {
    perror("Erro!!!");
  }
  else
  {
    if(lista_vazia(*lst))
    {
      printf("Lista vazia");
    }
    else
    {
      plista aux = *lst;
      plista aux2 = NULL;

      while(aux -> prox != NULL)//1.\ -> 2.\ -> 3.
      {
        aux2 = aux;
        aux = aux -> prox;
      }
      aux2 -> prox = NULL;
      free(aux);
    }
  }
}

void remover_n_lista(plista *lst,int x)
{
  if(lista_vazia(*lst))
  {
    printf("Lista vazia");
  }
  else
  {
    plista aux1 = *lst;
    plista aux2 = *lst;

    if(x == 1)
    {
      remover_no_ini_lista(lst);
    }
    else
    {
      for(int i = 0;i < x-1;i++)
      {
        aux2 = aux1;
        aux1 = aux1 -> prox;
      }
      aux2 -> prox = aux1 -> prox;
      free(aux1);
    }
  }
}

void remover_primeira_x(plista *lst,int x)
{
  if(lista(*lst))
  {
    printf("Lista vazia");
  }
  else
  {

  }
}
int main()
{
  plista pl = cria_lista();

  escreve_lista(pl);

  junta_no_ini_lista(1.21,&pl);
  junta_no_ini_lista(2.1,&pl);
  junta_no_ini_lista(3,&pl);

  escreve_lista(pl);

  junta_no_fim_lista(10.12,&pl);
  junta_no_fim_lista(1.12,&pl);

  escreve_lista(pl);

  remover_no_ini_lista(&pl);

  escreve_lista(pl);

  remover_no_fim_lista(&pl);

  escreve_lista(pl);

  remover_n_lista(&pl,1);

  escreve_lista(pl);
  return 11;
}
