#include <stdio.h>

float fibonaciIt(int n)
{
  int f1 = 1;
  int f2 = 1;
  int fib = 1;

  for(int i = 3;i <= n;i++)
  {
    fib = f1 + f2;
    f1 = f2;
    f2 = fib;
  }
  return fib;
}

float fibonaciRec(int n)
{
  if(n == 1 || n == 2)
    return 1;
  else
    return fibonaciRec(n-1) + fibonaciRec(n-2);
}

int main()//fibonaci
{
  int n = 6;
  float p;

  printf("Interativo: %.0f\n",p = fibonaciIt(n));
  printf("Recursividade: %.0f",p = fibonaciRec(n));

	return 0;
}
