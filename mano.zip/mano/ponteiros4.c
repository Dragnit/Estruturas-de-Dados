#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int tamanho_str(char *ps)
{
  int count = 0;

  while(*ps != '\0')
  {
    count++;
    ps++;
  }

  return count;
}

char * copia_substr(char * src,int i,int len)
{
  char * pst = malloc(sizeof(char)*(len+1));
  char * aux = pst;

  src += i;

  for(int j = 1;j <= len;j++)
  {
    if(*src == '\0')
    {
      break;
    }
    else
    {
      *aux = *src;
      aux++;
      src++;
    }
  }
  *aux = '\0';

  return pst;
}

int main()
{
  char string[] = "uma stringjyvhnknm";

  printf("'%s' tem %i letras.\n",string,tamanho_str(&string[0]));

  printf("'%s' tem como substring %s.",string,copia_substr(&string[0],4,6));

  return 0;
}
