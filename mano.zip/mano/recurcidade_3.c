#include <stdio.h>

void inverter_it(int tab[],int n)
{
  int aux;

  for(int i = 0;i < n/2;i++)
  {
    aux = tab[i];
    tab[i] = tab[n-i-1];
    tab[n-i-1] = aux;
  }

}

void inverter_rec(int n[])
{

}

int main()
{
  int n = 5;
  int tabela[] = {1,4,2,5,3};

  for(int i = 0;i < n;i++)
  {
    printf("%d ",tabela[i]);
  }

  inverter_it(tabela,n);
  printf("\n");

  for(int i = 0;i < n;i++)
  {
    printf("%d ",tabela[i]);
  }
	return 0;
}
