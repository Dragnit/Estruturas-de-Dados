#include <stdio.h>

#define TAM 3

void iniciar_matrizA(float *pm)
{
  for(int i = 0;i < TAM*TAM;i++)
  {
    *pm = -1;
    pm++;
  }
}

void escrever_matriz(float *pm)
{
  for(int i = 0;i < TAM*TAM;i++)
  {
    printf("%i = %.2f\n",++i,*pm);
    pm++;
    i--;
  }
}

void iniciar_matrizB(float *pm)
{
  int p = 1;
  for(int i = 0;i < TAM*TAM;i++)
  {
    *pm = p;
    pm++;
    p++;
  }
}

void atribuir_valor(float *pm,int i,int j)
{
  float num,pos;

  pos = i*TAM + j;

  for(int i = 0;i < pos;i++)
  {
    pm++;
  }
  printf("Indique um numero: ");scanf("%f",&num);

  *pm = num;
}

float * soma(float * pm1,float *pm2)
{
  float m[TAM][TAM];
  float g[TAM][TAM];

  pm1 = &m[0][0];
  pm2 = &g[0][0];

  return *pm1,*pm2;
}

int main()
{
  float v[TAM][TAM];

  float *pm;

  pm = &v[0][0];

  float *pm1,*pm2;

  int i,j;

  float a;

  //iniciar_matrizA(pm);

  //iniciar_matrizB(pm);

  //atribuir_valor(pm,2,2);

  a = soma(pm1,pm2);

  escrever_matriz(pm);

	return 0;
}
