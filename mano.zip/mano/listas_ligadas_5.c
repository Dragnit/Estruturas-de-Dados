#include <stdio.h>
#include <stdlib.h>

typedef struct dude * plista;

typedef struct dude
{
  float valor;
  plista prox;
}lista;

typedef struct tabPonteiros
{
  plista head,tail;
}ponteiros;

int lista_vazia(plista p)
{
  if(p == NULL)
    return 1;
  else
    return 0;
}

void acrescentar_x(plista p,float x)
{
  plista no = (plista)malloc(sizeof(lista));

  if(no == NULL)
  {
    perror("Erro");
  }
  else
  {
    no -> valor = x;
    no -> prox = NULL;

    if(lista_vazia(*p))
      *p = no;
    else
    {
      plista aux = *p;

      while(aux -> prox != NULL)
      {
        aux = aux -> prox;
      }
      aux -> prox = no; 
    }
  }
}

void escreve_lista(ppilha p)
{
  if(lista_vazia(p))
  {
    printf("Lista vazia\n");
  }
  else
  {
    printf("[");

    do
    {
      printf(" %.2f,",p -> valor);
      p = p -> prox;

    }while(p != NULL);
    printf("\b ]\n");
  }
}

int main()
{
  plista tp[2];

  tp[0] = NULL;
  tp[1] = NULL;

  plista no = (plista)malloc(sizeof(lista));

  no -> valor = 23.2;
  no -> prox = NULL;

  tp[0] = no;
  tp[1] = no;

  ponteiros ps;

  ps.head = NULL;
  ps.tail = NULL;

  ps.head = no;
  ps.tail = no;

  int a = lista_vazia(ps.head);
  if(a == 1)
    printf("Lista vazia");
  else
    printf("NO");


	return 0;
}
